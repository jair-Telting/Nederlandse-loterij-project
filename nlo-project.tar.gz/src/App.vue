<script setup>
import { ref, onMounted } from 'vue'
import HomeSection from './components/HomeSection.vue'
import Grid from './components/Grid.vue'
import nloLogo from './assets/nlologo.webp'

const gameStarted = ref(false)

onMounted(() => {
  const saved = localStorage.getItem('nlo:started')
  if (saved === '1') {
    gameStarted.value = true
  }
})

function startGame() {
  gameStarted.value = true
  localStorage.setItem('nlo:started', '1')
}

function quitGame() {
  gameStarted.value = false
  localStorage.removeItem('nlo:started')
}
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="topbar-brand">
        
        <span class="topbar-title">Nederlandse Loterij</span>
      </div>

      <div class="topbar-actions">
        <button class="topbar-link" type="button">Registreren</button>
        <button class="topbar-login" type="button">Inloggen</button>
      </div>
    </header>

    <main class="main-area">
      <HomeSection />

      <section v-if="!gameStarted" class="start-stage">
        <button class="start-button" type="button" @click="startGame">Start Game</button>
      </section>

      <section class="game-stage">
        <div v-if="gameStarted">      
            <Grid @quit="quitGame" />
        </div>
      </section>
    </main>
  </div>
</template>

<style scoped>
.app-shell {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 12px 32px;
  background: #0e3a78;
  color: #fff;
}

.topbar-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}

.topbar-logo {
  width: px;
  height: 28px;
  object-fit: contain;
}

.topbar-title {
  font-size: 0.95rem;
  font-weight: 700;
  letter-spacing: 0.04em;
}

.topbar-actions {
  display: flex;
  align-items: center;
  gap: 10px;
}

.topbar-link,
.topbar-login {
  border: 0;
  border-radius: 6px;
  padding: 10px 18px;
  font: inherit;
  font-weight: 700;
  cursor: pointer;
}

.topbar-link {
  background: transparent;
  color: #fff;
  padding-inline: 8px;
}

.topbar-login {
  background: #ffd21f;
  color: #111827;
}

.start-stage {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 160px;
}

.start-button {
  border: 0;
  border-radius: 999px;
  background: linear-gradient(180deg, #ff8a2a, #ff6a00);
  color: #fff;
  font: inherit;
  font-weight: 800;
  padding: 16px 28px;
  cursor: pointer;
  box-shadow: 0 14px 28px rgba(255, 106, 0, 0.22);
}

.game-stage {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.main-area {
  flex: 1;
  padding: 12px 32px 24px;
  display: flex;
  flex-direction: column;
  gap: 28px;
}

.section-heading h2,
.welcome-text {
  margin: 0;
}

.section-heading p,
.locked-card {
  margin: 4px 0 0;
}

.locked-card {
  padding: 14px 16px;
  border: 1px solid var(--border);
  background: rgba(239, 230, 217, 0.75);
  border-radius: 14px;
  color: var(--text);
}

.welcome-card {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

@media (max-width: 1024px) {
  .topbar,
  .main-area {
    padding-left: 18px;
    padding-right: 18px;
  }
}

@media (max-width: 640px) {
  .topbar {
    flex-direction: column;
    align-items: flex-start;
  }

  .topbar-actions {
    width: 100%;
    justify-content: flex-start;
  }
}
</style>
