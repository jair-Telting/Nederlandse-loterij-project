<script setup>
import nloLogo from '../assets/nlologo.webp'
import staatsloterij from '../assets/staatsloterij.webp'
import eurojackpot from '../assets/eurojackpot.webp'
import lotto from '../assets/lotto.webp'
import luckyday from '../assets/luckyday.webp'
import miljoenspel from '../assets/miljoenspel.webp'
import krasloten from '../assets/krasloten.webp'
import toto from '../assets/toto.png'

const gameBanners = [
  { name: 'Staatsloterij', href: 'https://www.staatsloterij.nl', image: staatsloterij, blurb: 'De klassieke loterij met grote trekkingen.' },
  { name: 'Eurojackpot', href: 'https://www.eurojackpot.nl', image: eurojackpot, blurb: 'Twee keer per week kans op een enorme jackpot.' },
  { name: 'Lotto', href: 'https://www.lotto.nl', image: lotto, blurb: 'Simpel meespelen met vaste trekkingmomenten.' },
  { name: 'Lucky Day', href: 'https://www.luckyday.nl', image: luckyday, blurb: 'Elke dag een nieuwe kans op prijs.' },
  { name: 'Miljoenenspel', href: 'https://www.miljoenspel.nl', image: miljoenspel, blurb: 'Rond bedrag, directe spanning en grote prijzen.' },
  { name: 'Krasloten', href: 'https://www.krasloten.nl', image: krasloten, blurb: 'Kras en ontdek direct wat je hebt gewonnen.' },
  { name: 'TOTO', href: 'https://www.toto.nl', image: toto, blurb: 'Voorspellen, meespelen en live spanning.' },
]
</script>

<template>
  <section class="home-stage">
    <div class="brand">
      <img class="brand-logo" :src="nloLogo" alt="Nederlandse Loterij" />
      <p class="home-header">Nederlandse Loterij</p>
    </div>

    <section class="banner-strip" aria-label="Nederlandse Loterij games">
      <a
        v-for="game in gameBanners"
        :key="game.name"
        class="game-banner"
        :href="game.href"
        target="_blank"
        rel="noreferrer"
      >
        <span class="banner-art" :style="{ backgroundImage: `url(${game.image})` }" aria-hidden="true"></span>
        <span class="banner-content">
          <span class="banner-title">{{ game.name }}</span>
          <span class="banner-blurb">{{ game.blurb }}</span>
        </span>
      </a>
    </section>
  </section>
</template>

<style scoped>
.home-stage {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.brand {
  display: flex;
  align-items: center;
  gap: 18px;
}

.brand-logo {
  width: 72px;
  height: 72px;
  object-fit: contain;
  flex: none;
}

.home-header {
  margin: 0;
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.14em;
  color: var(--accent);
  font-weight: 700;
}

.banner-strip {
  display: grid;
  grid-template-columns: repeat(7, minmax(0, 1fr));
  gap: 10px;
  padding: 0;
  overflow: visible;
}

.game-banner {
  min-height: 154px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 12px 10px;
  border-radius: 18px;
  border: 1px solid rgba(30, 64, 175, 0.14);
  background: linear-gradient(180deg, rgba(232, 240, 255, 0.98), rgba(255, 255, 255, 0.98));
  text-decoration: none;
  color: inherit;
  box-shadow: var(--shadow);
  text-align: center;
}

.banner-art {
  width: 100%;
  height: 60px;
  flex: none;
  border-radius: 14px;
  background-color: rgba(14, 58, 120, 0.06);
  background-position: center;
  background-repeat: no-repeat;
  background-size: contain;
  border: 1px solid rgba(14, 58, 120, 0.1);
}

.banner-content {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  width: 100%;
}

.banner-title {
  font-weight: 800;
  color: #0e3a78;
  font-size: 0.96rem;
}

.banner-blurb {
  font-size: 0.8rem;
  line-height: 1.28;
  color: var(--text);
}

@media (max-width: 1024px) {
  .banner-strip {
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  }
}

@media (max-width: 640px) {
  .brand-logo {
    width: 56px;
    height: 56px;
  }

  .banner-strip {
    grid-template-columns: 1fr;
  }

  .game-banner {
    min-height: 156px;
  }
}
</style>