<script setup>
import { ref, computed, onMounted } from 'vue'

const emit = defineEmits(['quit'])

const SIZE = 100
const COUNT = SIZE * SIZE
const LOCAL_PRIZE_KEY = 'nlo:prizes'
const LOCAL_OPENED_KEY = 'nlo:opened'
const LOCAL_CLAIMED_KEY = 'nlo:claimed'

const GRAND_AMOUNT = 25000
const CONSOLATION_AMOUNT = 100
const CONSOLATION_COUNT = 100

const prizes = ref(new Array(COUNT).fill(0))
const opened = ref(new Array(COUNT).fill(false))
const claimed = ref(new Array(COUNT).fill(false))

function saveState() {
  localStorage.setItem(LOCAL_PRIZE_KEY, JSON.stringify(prizes.value))
  localStorage.setItem(LOCAL_OPENED_KEY, JSON.stringify(opened.value))
  localStorage.setItem(LOCAL_CLAIMED_KEY, JSON.stringify(claimed.value))
}

function loadState() {
  const rawPrizes = localStorage.getItem(LOCAL_PRIZE_KEY)
  const rawOpened = localStorage.getItem(LOCAL_OPENED_KEY)
  const rawClaimed = localStorage.getItem(LOCAL_CLAIMED_KEY)
  if (rawPrizes) {
    try {
      const parsed = JSON.parse(rawPrizes)
      if (Array.isArray(parsed) && parsed.length === COUNT) {
        prizes.value = parsed
      }
    } catch (e) {}
  }
  if (rawOpened) {
    try {
      const parsedOpen = JSON.parse(rawOpened)
      if (Array.isArray(parsedOpen) && parsedOpen.length === COUNT) {
        opened.value = parsedOpen
      }
    } catch (e) {}
  }
  if (rawClaimed) {
    try {
      const parsedClaimed = JSON.parse(rawClaimed)
      if (Array.isArray(parsedClaimed) && parsedClaimed.length === COUNT) {
        claimed.value = parsedClaimed
      }
    } catch (e) {}
  }
  if (!rawPrizes) {
    initDistribution()
  }
}

function initDistribution() {
  const indices = Array.from({ length: COUNT }, (_, i) => i)
  for (let i = COUNT - 1; i > 0; i--) {
    const rand = crypto.getRandomValues(new Uint32Array(1))[0]
    const j = rand % (i + 1)
    const tmp = indices[i]
    indices[i] = indices[j]
    indices[j] = tmp
  }
  prizes.value.fill(0)
  prizes.value[indices[0]] = 1
  for (let k = 1; k <= CONSOLATION_COUNT; k++) {
    prizes.value[indices[k]] = 2
  }
  opened.value.fill(false)
  claimed.value.fill(false)
  saveState()
}

function revealCell(id) {
  if (opened.value[id]) return
  opened.value[id] = true
  saveState()
}

const claimableTotal = computed(() => {
  let total = 0
  for (let i = 0; i < COUNT; i++) {
    if (opened.value[i] && !claimed.value[i]) {
      if (prizes.value[i] === 1) total += GRAND_AMOUNT
      else if (prizes.value[i] === 2) total += CONSOLATION_AMOUNT
    }
  }
  return total
})

const claimableCount = computed(() => {
  let c = 0
  for (let i = 0; i < COUNT; i++) {
    if (opened.value[i] && !claimed.value[i] && prizes.value[i] > 0) c++
  }
  return c
})

function claimPrize() {
  const total = claimableTotal.value
  if (!total) return alert('No prizes to claim')
  for (let i = 0; i < COUNT; i++) {
    if (opened.value[i] && !claimed.value[i] && prizes.value[i] > 0) {
      claimed.value[i] = true
    }
  }
  saveState()
  alert(`You claimed ${new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(total)}`)
}

function clearSavedState() {
  localStorage.removeItem(LOCAL_PRIZE_KEY)
  localStorage.removeItem(LOCAL_OPENED_KEY)
  localStorage.removeItem(LOCAL_CLAIMED_KEY)
}

function quitGame() {
  clearSavedState()
  prizes.value = new Array(COUNT).fill(0)
  opened.value = new Array(COUNT).fill(false)
  claimed.value = new Array(COUNT).fill(false)
  emit('quit')
}

const indicesArray = computed(() => Array.from({ length: COUNT }, (_, i) => i))

const openedCount = computed(() => opened.value.filter(Boolean).length)
const remainingGrand = computed(() => prizes.value.filter((p) => p === 1).length - opened.value.reduce((acc, cur, idx) => acc + (cur && prizes.value[idx] === 1 ? 1 : 0), 0))
const remainingConsolation = computed(() => prizes.value.filter((p) => p === 2).length - opened.value.reduce((acc, cur, idx) => acc + (cur && prizes.value[idx] === 2 ? 1 : 0), 0))
const formattedClaimable = computed(() => new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(claimableTotal.value))

onMounted(() => {
  loadState()
})
</script>

<template>
  <div class="grid-root">
    <div class="info">
      <div class="counters">
        <span class="counter">Open: {{ openedCount }}</span>
        <span class="counter">Jackpots left: {{ remainingGrand }}</span>
        <span class="counter">Consolation left: {{ remainingConsolation }}</span>
      </div>
      <div class="legend">
        <div class="legend-item"><span class="box sample grand"></span> €25.000</div>
        <div class="legend-item"><span class="box sample consolation"></span> €100</div>
        <div class="legend-item"><span class="box sample none"></span> nothing</div>
      </div>
      <div class="actions">
        <button class="claim-button" :disabled="claimableTotal === 0" @click="claimPrize">Claim Prize ({{ formattedClaimable }})</button>
        <button class="reset-button" @click="quitGame">Quit</button>
      </div>
    </div>

    <div class="grid-container" role="grid" aria-label="NLO kalender">
      <div
        v-for="i in indicesArray"
        :key="i"
        class="cell"
        :class="{ opened: opened[i], grand: opened[i] && prizes[i] === 1, consolation: opened[i] && prizes[i] === 2 }"
        @click="revealCell(i)"
        role="button"
        :aria-pressed="opened[i]"
      >
        <span class="label" v-if="opened[i]">
          <template v-if="prizes[i] === 1">€25k</template>
          <template v-else-if="prizes[i] === 2">€100</template>
          <template v-else>—</template>
        </span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.grid-root {
  display: flex;
  flex-direction: column;
  gap: 12px;
  align-items: center;
}

.info {
  width: 100%;
  max-width: 1100px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  box-sizing: border-box;
}

.counters {
  display: flex;
  gap: 12px;
  align-items: center;
}

.counter {
  font-family: system-ui, Roboto, sans-serif;
  background: rgba(14, 58, 120, 0.06);
  color: #0e3a78;
  padding: 6px 10px;
  border-radius: 8px;
  border: 1px solid rgba(14, 58, 120, 0.08);
}


.legend {
  display: flex;
  gap: 12px;
  align-items: center;
}

.legend-item {
  display:flex;
  gap:8px;
  align-items:center;
  background: rgba(14, 58, 120, 0.06);
  color: #0e3a78;
  padding: 6px 10px;
  border-radius: 8px;
  border: 1px solid rgba(14, 58, 120, 0.08);
}
.box.sample { width:18px; height:14px; display:inline-block; border-radius:3px; border:1px solid rgba(14,58,120,0.08) }
.box.sample.grand { background: gold }
.box.sample.consolation { background: lightgreen }
.box.sample.none { background: #eee }

.actions { display:flex; gap:10px; align-items:center }
.claim-button,
.reset-button { padding:8px 12px; border-radius:8px; border:0; font-weight:700; cursor:pointer }
.claim-button[disabled] { opacity:0.48; cursor:not-allowed }
.claim-button { background: linear-gradient(180deg,#ffb86b,#ff8a2a); color:#111 }
.reset-button { background: #efe6d9; color: #3b2b2b }

.grid-container {
  display: grid;
  grid-template-columns: repeat(100, 10px);
  grid-auto-rows: 10px;
  gap: 3px;
  width: fit-content;
  justify-content: center;
  max-width: 100%;
  overflow: auto;
  padding: 8px;
}

.cell {
  width: 10px;
  height: 10px;
  background: #ddd;
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 8px;
  cursor: pointer;
  user-select: none;
}

.cell:hover { filter: brightness(0.95) }

.cell.opened { background: #f3f3f3; cursor: default }
.cell.opened .label { font-size: 8px; color: #111 }
.cell.opened.grand { background: gold }
.cell.opened.consolation { background: lightgreen }

.label { font-family: ui-monospace, monospace; font-size: 7px }


</style>

