<script setup>
import { ref } from 'vue'

const emit = defineEmits(['login'])
const name = ref('')

function submit(e) {
  e.preventDefault()
  const v = name.value.trim()
  if (!v) return alert('Please enter a name')
  emit('login', v)
}
</script>

<template>
  <div class="login-root">
    <form class="login-form" @submit="submit">
        <h2>Login</h2>
        <div class="login-panel">
          <input class="login-input" v-model="name" placeholder="Your name" aria-label="name" />
          <button class="login-button" type="submit">Enter</button>
        </div>
      </form>
  </div>
</template>

<style scoped>
  .login-root { display:flex; align-items:center; justify-content:center; height:60vh }
  .login-form { display:flex; flex-direction:column; gap:12px; background: var(--accent-bg); padding:20px; border-radius:10px; border:1px solid var(--accent-border) }
  .login-panel { display:flex; gap:10px; align-items:center }
  .login-input { padding:10px 12px; font-size:15px; background:#efe6d9; border:1px solid var(--border); border-radius:8px; color:var(--text); outline:none }
  .login-input::placeholder { color: #9a8f86 }
  .login-button { padding:10px 14px; font-size:15px; cursor:pointer; background:#efe6d9; border:1px solid var(--border); border-radius:8px; color:var(--text-h); font-weight:600 }
  .login-button:hover { filter:brightness(0.98) }
</style>
